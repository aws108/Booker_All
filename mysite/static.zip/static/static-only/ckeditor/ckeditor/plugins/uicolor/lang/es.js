﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","es",{title:"Recolector de Color de Interfaz de Usuario",preview:"Vista previa en vivo",config:"Pega esta cadena en tu archivo config.js",predefined:"Conjuntos predefinidos de colores"});